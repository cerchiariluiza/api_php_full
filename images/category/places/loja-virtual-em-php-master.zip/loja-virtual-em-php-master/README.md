# loja-virtual-em-php

INICIO de um projeto de loja virtual usando PHP, JAVASCRIPT, JQUERY, MYSQL, BOOTSTRAP, CSS3
<br/>
Alexandre Ximenes Email : xyymenes@gmail.com
<br/>
<p>Loja virtual feito em php para treinamento e desenvolvimento de aprendizagem da linguagem</p>
Site no hostinger <a href="http://alexandreximenes.esy.es/"> http://alexandreximenes.esy.es/ </a>

<p>
  <br/>Tela principal
 <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/1.PNG" alt="tela principal">
</p>
<p>
  <br/>..continuação tela principal
   <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/2.PNG" alt="tela principal">
</p>
<p>
  <br/>Tela - Cadastrar novo jogo
  <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/3.PNG" alt="cadastrar novo jogo">
</p>
<p>
    <br/>Tela - Editando as informações de um jogo
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/6.PNG" alt="Editando um as informações de um jogo">
</p>
<p>
  <br/>Tela - Lista de jogos
  <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/4.PNG" alt="listar jogos">
</p>
<p>
    <br/>Tela - Cadastrar novo cliente
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/5.PNG" alt="Cadastrar cliente">
</p>
<p>
    <br/>Tela - Tela auxiliar para comprar jogos
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/6.PNG" alt="Comprar jogos">
</p>
<p>
    <br/>Tela - Enviar email
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/7.PNG" alt="Enviar email">
</p>
<p>
    <br/>Tela - Cliente logado no sistema
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/8.PNG" alt="cliente logado">
</p>
<p>
    <br/>Tela - Cliente deslogado no sistema
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/9.PNG" alt="cliente deslogado no sistema">
</p>
<p>
    Tela - login incorreto
    <br/>
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/10.PNG" alt="Login incorreto">
</p>
<p>
    Tela - Carrinho de compras com 2 itens 
    <br/>Pedido de exemplo : 28
    <img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/12.PNG" alt="Carrinho de compras com 2 compras até o momento">
</p>
<p>
    Tela - Pedido finalizado, incluido pedido no sistema, enviado email dos detalhes da compra ao cliente
    <br/>Pedido de exemplo : 68
    <br/><img src="https://github.com/alexandreximenes/loja-virtual-em-php/blob/master/sistemavendas/print-telas/13.PNG" alt="Pedido finalizado, enviado email com os dados do pedido">
</p>
